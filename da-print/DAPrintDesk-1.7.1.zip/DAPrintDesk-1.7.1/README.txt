DA Print Desk 1.7.1 - by Digital Arts, Port Blair
=================================================
Prints online orders from your DA Print shop (print.datpl.com).

1. Keep this whole folder together (DAPrintDesk.exe + x64 + x86 folders).
2. Double-click DAPrintDesk.exe. If Windows says "Windows protected your PC",
   click "More info" -> "Run anyway".
3. Sign in with your DA Print email and password.
4. Choose your B&W, colour and (optional) photo printer, then press "Test print".

Word / Excel / PowerPoint files need Microsoft Office or LibreOffice on this PC.
Closing the window keeps it running next to the clock. Right-click the icon -> Exit to quit.
Help: WhatsApp +91 99332 11177

PDF engine: PDFium (c) The PDFium Authors, BSD/Apache licence - see LICENSE-pdfium.txt

More printers: press "More printers..." to choose a printer for each print type
(for example a separate printer loaded with photo paper or A3).
Updates: the app tells you when a new version is ready (right-click icon -> Check for updates).
One printer only? Choose it as the B&W printer and leave the others empty. In "More printers..." tick
"Ask first (load paper)" for photo paper: the app stops and asks you to load the paper before printing it.
